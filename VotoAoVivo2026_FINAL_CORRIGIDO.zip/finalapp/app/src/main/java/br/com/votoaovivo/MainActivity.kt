package br.com.votoaovivo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF071A31)
private val Blue = Color(0xFF0C5BEF)
private val Gold = Color(0xFFF5C451)
private val Bg = Color(0xFFF4F7FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "tse-candidates",
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<SyncWorker>(6, TimeUnit.HOURS).build()
        )
        setContent { VotoApp() }
    }
}

class AppState(private val context: android.content.Context) : ViewModel() {
    var candidates by mutableStateOf<List<Candidate>>(emptyList())
        private set
    var favorites by mutableStateOf<Set<String>>(emptySet())
        private set
    var results by mutableStateOf<ResultSnapshot?>(null)
        private set
    var selectedOffice by mutableStateOf("0001")
    var selectedUf by mutableStateOf("br")
    var loading by mutableStateOf(false)
        private set

    init {
        favorites = context.getSharedPreferences("prefs", 0)
            .getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
        refreshCandidates()
    }

    fun toggleFavorite(id: String) {
        val next = favorites.toMutableSet()
        if (!next.add(id)) next.remove(id)
        favorites = next
        context.getSharedPreferences("prefs", 0).edit()
            .putStringSet("favorites", next).apply()
    }

    fun refreshCandidates() {
        viewModelScope.launch {
            loading = true
            candidates = TseClient.syncCandidates(context)
            loading = false
        }
    }

    fun refreshResult() {
        viewModelScope.launch {
            loading = true
            results = TseClient.result(selectedOffice, selectedUf)
            loading = false
        }
    }
}

@Composable
fun VotoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state: AppState = viewModel(factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AppState(context.applicationContext) as T
        }
    })
    var tab by remember { mutableIntStateOf(0) }
    var selectedCandidate by remember { mutableStateOf<Candidate?>(null) }
    var search by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Bg, surface = Color.White)) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    val icons = listOf(Icons.Default.Home, Icons.Default.Search, Icons.Default.Star, Icons.Default.BarChart)
                    val labels = listOf("Início", "Pesquisar", "Favoritos", "Resultados")
                    icons.forEachIndexed { index, icon ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(imageVector = icon, contentDescription = labels[index]) },
                            label = { Text(labels[index]) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(Bg)
            ) {
                when (tab) {
                    0 -> Home(state)
                    1 -> SearchPage(state, search, { search = it }, { selectedCandidate = it })
                    2 -> FavoritesPage(state) { selectedCandidate = it }
                    3 -> ResultsPage(state)
                }
                selectedCandidate?.let { candidate ->
                    CandidateProfile(candidate, state) { selectedCandidate = null }
                }
            }
        }
    }
}

@Composable
fun Header(title: String = "VOTO AO VIVO") {
    Row(
        modifier = Modifier.fillMaxWidth().background(Navy).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            Text("Eleições 2026", color = Color.White.copy(alpha = .65f), fontSize = 12.sp)
        }
        val transition = rememberInfiniteTransition(label = "live")
        val alpha by transition.animateFloat(
            initialValue = 1f,
            targetValue = .25f,
            animationSpec = infiniteRepeatable(tween(750), RepeatMode.Reverse),
            label = "pulse"
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).alpha(alpha).clip(CircleShape).background(Color.Red))
            Spacer(Modifier.width(6.dp))
            Text("AO VIVO", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun Home(state: AppState) {
    Header()
    Column(Modifier.padding(16.dp)) {
        Text("Acompanhe a apuração", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Dados eleitorais oficiais quando disponibilizados.", color = Color.Gray)
        Spacer(Modifier.height(18.dp))
        LiveCard(state)
        Spacer(Modifier.height(18.dp))
        val offices = listOf(
            "0001" to "Presidente",
            "0003" to "Governador",
            "0005" to "Senador",
            "0006" to "Deputado Federal",
            "0007" to "Deputado Estadual"
        )
        offices.forEach { (code, name) -> ElectionCard(name, code, state) }
    }
}

@Composable
fun LiveCard(state: AppState) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Navy)) {
        Column(Modifier.padding(20.dp)) {
            Text("STATUS DA APURAÇÃO", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(
                if (state.results?.final == true) "RESULTADO FINAL" else "Aguardando / apuração em andamento",
                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold
            )
            Text(
                if (!state.results?.updatedAt.isNullOrBlank()) "Última atualização: ${state.results?.updatedAt}"
                else "A fonte oficial será consultada automaticamente.",
                color = Color.White.copy(alpha = .7f)
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { state.refreshResult() },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)
            ) { Text("Atualizar agora", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun ElectionCard(name: String, code: String, state: AppState) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).clickable {
            state.selectedOffice = code
            state.refreshResult()
        },
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Navy)
                Icon(Icons.Default.ChevronRight, contentDescription = null)
            }
            if (state.results?.office == name && !state.results?.candidates.isNullOrEmpty()) {
                state.results!!.candidates.take(3).forEach { result ->
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${result.position}º", Modifier.width(28.dp), fontWeight = FontWeight.Bold)
                        Text(result.name, Modifier.weight(1f))
                        Text("${result.percent.format()}%", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Text("Toque para consultar a totalização oficial", color = Color.Gray, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun SearchPage(state: AppState, query: String, onQuery: (String) -> Unit, onSelect: (Candidate) -> Unit) {
    Header("Pesquisar candidatos")
    Column(Modifier.padding(14.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Nome, número ou partido") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )
        Spacer(Modifier.height(10.dp))
        val list = state.candidates.filter {
            val q = query.trim()
            q.isBlank() || it.name.contains(q, true) || it.ballotName.contains(q, true) ||
                it.number.contains(q) || it.party.contains(q, true)
        }.take(300)
        Text("${state.candidates.size} candidaturas carregadas", color = Color.Gray, fontSize = 12.sp)
        LazyColumn {
            items(list, key = { it.id }) { candidate -> CandidateRow(candidate, state, onSelect) }
        }
    }
}

@Composable
fun FavoritesPage(state: AppState, onSelect: (Candidate) -> Unit) {
    Header("Meus favoritos")
    val list = state.candidates.filter { it.id in state.favorites }
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Você ainda não favoritou candidatos.", color = Color.Gray)
        }
    } else {
        LazyColumn(Modifier.padding(14.dp)) {
            items(list, key = { it.id }) { candidate -> CandidateRow(candidate, state, onSelect) }
        }
    }
}

@Composable
fun CandidateRow(candidate: Candidate, state: AppState, onSelect: (Candidate) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { onSelect(candidate) },
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (candidate.photoUrl.isNotBlank()) {
                AsyncImage(
                    model = candidate.photoUrl,
                    contentDescription = candidate.ballotName,
                    modifier = Modifier.size(62.dp).clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(Modifier.size(62.dp).clip(CircleShape).background(Navy), contentAlignment = Alignment.Center) {
                    Text(candidate.ballotName.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(candidate.ballotName, fontWeight = FontWeight.Bold, color = Navy)
                Text("${candidate.party} • ${candidate.office}", fontSize = 12.sp, color = Color.Gray)
                Text("Nº ${candidate.number} • ${candidate.uf}", fontSize = 12.sp, color = Color.Gray)
            }
            IconButton(onClick = { state.toggleFavorite(candidate.id) }) {
                Icon(
                    imageVector = if (candidate.id in state.favorites) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Favorito",
                    tint = if (candidate.id in state.favorites) Gold else Color.Gray
                )
            }
        }
    }
}

@Composable
fun CandidateProfile(candidate: Candidate, state: AppState, close: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column {
            Row(
                Modifier.fillMaxWidth().background(Navy).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = close) { Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = Color.White) }
                Text("Perfil do candidato", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { state.toggleFavorite(candidate.id) }) {
                    Icon(
                        imageVector = if (candidate.id in state.favorites) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Favorito",
                        tint = Color.White
                    )
                }
            }
            LazyColumn(Modifier.padding(16.dp)) {
                item {
                    if (candidate.photoUrl.isNotBlank()) {
                        AsyncImage(
                            model = candidate.photoUrl,
                            contentDescription = candidate.ballotName,
                            modifier = Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(22.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(candidate.ballotName, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                    Text(candidate.name, fontSize = 15.sp, color = Color.Gray)
                    Spacer(Modifier.height(12.dp))
                    Info("Número", candidate.number)
                    Info("Cargo", candidate.office)
                    Info("Partido", if (candidate.partyName.isBlank()) candidate.party else "${candidate.party} — ${candidate.partyName}")
                    Info("UF", candidate.uf)
                    Info("Situação", candidate.situation)
                    Info("Vice", candidate.viceName)
                    Info("Ocupação", candidate.occupation)
                    Info("Instrução", candidate.education)
                    Spacer(Modifier.height(18.dp))
                    Text("Fonte", fontWeight = FontWeight.Bold, color = Navy)
                    Text(
                        "Dados cadastrais sincronizados a partir do conjunto público de Candidatos 2026 do TSE. Este aplicativo é independente.",
                        fontSize = 13.sp, color = Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
fun Info(label: String, value: String) {
    if (value.isNotBlank()) {
        Column(Modifier.padding(vertical = 7.dp)) {
            Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Text(value, fontSize = 16.sp, color = Navy)
        }
    }
}

@Composable
fun ResultsPage(state: AppState) {
    Header("Resultados")
    Column(Modifier.padding(14.dp)) {
        Text("Totalização oficial", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Brasil", color = Color.Gray)
        Spacer(Modifier.height(12.dp))
        state.results?.let { result ->
            Text(result.office, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Seções: ${result.sectionsCounted}/${result.sectionsTotal}")
            result.candidates.take(20).forEach { ResultRow(it) }
        } ?: Text("Selecione um cargo na página inicial para consultar os resultados.", color = Color.Gray)
    }
}

@Composable
fun ResultRow(result: ResultCandidate) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${result.position}º", Modifier.width(34.dp), fontWeight = FontWeight.Bold, color = Blue)
            Column(Modifier.weight(1f)) {
                Text(result.name, fontWeight = FontWeight.Bold)
                Text("${result.votes} votos", fontSize = 12.sp, color = Color.Gray)
            }
            Text("${result.percent.format()}%", fontWeight = FontWeight.ExtraBold, color = Navy)
        }
    }
}

private fun Double.format(): String = String.format(java.util.Locale("pt", "BR"), "%.2f", this)
