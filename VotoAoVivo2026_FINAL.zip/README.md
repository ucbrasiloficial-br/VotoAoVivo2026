# Voto ao Vivo 2026 — base limpa

Projeto Android mínimo para validar o pipeline de geração do APK.
Nesta primeira etapa não há dados eleitorais fictícios nem integração externa.
Depois que o APK compilar, as funcionalidades serão adicionadas em etapas.
