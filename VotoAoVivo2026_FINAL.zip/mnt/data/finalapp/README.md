# Voto ao Vivo — Eleições 2026

Aplicativo Android independente para consulta de candidaturas e acompanhamento de resultados oficiais das Eleições 2026.

## Fontes oficiais
- Candidaturas: https://dadosabertos.tse.jus.br/dataset/candidatos-2026
- Resultados: https://resultados.tse.jus.br
- Documentação técnica: https://www.tse.jus.br/eleicoes/informacoes-tecnicas-sobre-a-divulgacao-de-resultados

## Como funciona
1. Na primeira abertura, o app baixa o conjunto oficial de candidaturas 2026 e extrai os CSVs.
2. O banco local é mantido no SharedPreferences para uma primeira versão simples e resiliente.
3. A sincronização é repetida periodicamente em segundo plano.
4. Resultados são consultados diretamente na CDN oficial do TSE, usando os códigos oficiais publicados para 2026.
5. Antes de haver dados, o app não inventa votos: exibe aguardando/indisponível.
6. O status final só é mostrado quando o arquivo oficial indicar finalização.

## APK pelo celular
Este repositório contém `.github/workflows/android.yml`. Envie o projeto para GitHub e execute Actions > Build Android APK > Run workflow. O APK aparecerá como Artifact.

## Importante
O aplicativo é independente e não é desenvolvido pelo TSE. Não usar logotipo oficial do TSE nem sugerir vínculo institucional.

O aplicativo não deve alterar o conteúdo dos dados distribuídos pela Justiça Eleitoral. Apenas apresenta os dados recebidos, respeitando a documentação e os limites de acesso.
