package br.com.votoaovivo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.zip.ZipInputStream

object TseClient {
    private const val CANDIDATE_ZIP = "https://cdn.tse.jus.br/estatistica/sead/odsele/consulta_cand/consulta_cand_2026.zip"
    private const val RESULTS_BASE = "https://resultados.tse.jus.br"
    private const val ENV = "oficial"
    private const val CYCLE = "ele2026"
    private const val FEDERAL = "6257"
    private const val STATE = "6259"
    private const val DISTRICT = "6261"

    private fun get(url: String, etag: String? = null): Pair<Int, ByteArray?> {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000; readTimeout = 30_000
            requestProperty("User-Agent", "VotoAoVivo2026/1.0")
            if (!etag.isNullOrBlank()) requestProperty("If-None-Match", etag)
        }
        return try { c.connect(); c.responseCode to if (c.responseCode == 200) c.inputStream.use { it.readBytes() } else null } finally { c.disconnect() }
    }

    suspend fun syncCandidates(context: Context): List<Candidate> = withContext(Dispatchers.IO) {
        val prefs = context.getSharedPreferences("tse", Context.MODE_PRIVATE)
        val cached = prefs.getString("candidates", null)
        try {
            val (_, bytes) = get(CANDIDATE_ZIP)
            if (bytes == null) return@withContext parseCandidates(cached ?: "[]")
            val list = parseCandidateZip(bytes)
            prefs.edit().putString("candidates", JSONArray(list.map { JSONObject().apply {
                put("id",it.id);put("name",it.name);put("ballotName",it.ballotName);put("number",it.number);put("party",it.party);put("partyName",it.partyName);put("office",it.office);put("uf",it.uf);put("city",it.city);put("situation",it.situation);put("occupation",it.occupation);put("education",it.education);put("photoUrl",it.photoUrl);put("viceName",it.viceName)
            }}).toString()).putLong("candidateSync", System.currentTimeMillis()).apply()
            list
        } catch (_: Exception) { parseCandidates(cached ?: "[]") }
    }

    private fun parseCandidateZip(bytes: ByteArray): List<Candidate> {
        val out = LinkedHashMap<String, Candidate>()
        ZipInputStream(bytes.inputStream()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                if (!e.name.lowercase().endsWith(".csv") || !e.name.lowercase().contains("consulta_cand_")) continue
                val text = zis.readBytes().toString(Charsets.ISO_8859_1)
                val lines = text.split("\\n")
                if (lines.isEmpty()) continue
                val header = splitCsv(lines[0]).map { it.trim().removePrefix("\\uFEFF") }
                val idx = header.withIndex().associate { it.value to it.index }
                for (line in lines.drop(1)) {
                    if (line.isBlank()) continue
                    val v = splitCsv(line)
                    fun p(vararg keys: String) = keys.firstNotNullOfOrNull { k -> idx[k]?.let { i -> v.getOrNull(i)?.trim()?.takeIf { it.isNotEmpty() } } }
                    val id = p("SQ_CANDIDATO") ?: continue
                    val full = p("NM_CANDIDATO") ?: continue
                    val office = p("DS_CARGO") ?: ""
                    out[id] = Candidate(id, full, p("NM_URNA_CANDIDATO") ?: full, p("NR_CANDIDATO") ?: "", p("SG_PARTIDO") ?: "", p("NM_PARTIDO") ?: "", office, p("SG_UF") ?: "", p("NM_UE") ?: "", p("DS_SITUACAO_CANDIDATURA") ?: p("DS_SITUACAO") ?: "", p("DS_OCUPACAO") ?: "", p("DS_GRAU_INSTRUCAO") ?: "", p("URL_FOTO") ?: p("URL_FOTO_CANDIDATO") ?: "", p("NM_VICE") ?: "")
                }
            }
        }
        return out.values.toList()
    }

    private fun splitCsv(line: String): List<String> {
        val r = mutableListOf<String>(); val sb = StringBuilder(); var quote = false; var i = 0
        while (i < line.length) { val ch=line[i]; if(ch=='"'){ if(quote && i+1<line.length && line[i+1]=='"'){sb.append('"');i++}else quote=!quote }else if(ch==';'&&!quote){r+=sb.toString();sb.clear()}else sb.append(ch);i++ }; r+=sb.toString(); return r
    }

    private fun parseCandidates(json: String): List<Candidate> { val a=JSONArray(json); return (0 until a.length()).map { o -> val x=a.getJSONObject(o); Candidate(x.optString("id"),x.optString("name"),x.optString("ballotName"),x.optString("number"),x.optString("party"),x.optString("partyName"),x.optString("office"),x.optString("uf"),x.optString("city"),x.optString("situation"),x.optString("occupation"),x.optString("education"),x.optString("photoUrl"),x.optString("viceName")) } }

    suspend fun result(officeCode: String, uf: String = "br"): ResultSnapshot = withContext(Dispatchers.IO) {
        val election = if (officeCode == "0001") FEDERAL else if (uf.equals("df",true)) DISTRICT else STATE
        val url = "$RESULTS_BASE/$ENV/$CYCLE/$election/dados/${uf.lowercase()}/${uf.lowercase()}-c$officeCode-e$election-u.json"
        val (_, bytes) = get(url)
        if (bytes == null) return@withContext ResultSnapshot(officeName(officeCode), uf, emptyList())
        parseResult(bytes.toString(Charsets.UTF_8), officeName(officeCode), uf)
    }

    private fun officeName(code: String) = when(code){"0001"->"Presidente";"0003"->"Governador";"0005"->"Senador";"0006"->"Deputado Federal";"0007"->"Deputado Estadual";"0008"->"Deputado Distrital";else->"Resultado"}

    private fun parseResult(json: String, office: String, uf: String): ResultSnapshot {
        val root=JSONObject(json); val found=mutableListOf<ResultCandidate>(); walk(root,found)
        val unique=found.groupBy { if(it.number.isNotBlank()) it.number else it.id }.map { it.value.maxByOrNull{v->v.votes}!! }.sortedByDescending{it.votes}.mapIndexed{idx,v->v.copy(position=idx+1)}
        val sectionsTotal=findLong(root,"tot","qt","qts","totalSecoes")
        val sectionsCount=findLong(root,"s","sc","secoesTotalizadas","qtSecoesTotalizadas")
        val valid=findLong(root,"v","vv","votosValidos"); val blank=findLong(root,"vb","brancos","votosBrancos"); val nul=findLong(root,"vn","nulos","votosNulos"); val turnout=findLong(root,"tv","comparecimento"); val abst=findLong(root,"a","abstencoes")
        val updated=findString(root,"dt","dh","dataHora","atualizacao") ?: ""
        val final=(findString(root,"and","f","final") ?: "").lowercase() in setOf("f","true","1")
        return ResultSnapshot(office,uf,unique,sectionsTotal.toInt(),sectionsCount.toInt(),valid,blank,nul,turnout,abst,updated,final)
    }

    private fun walk(v: Any, out: MutableList<ResultCandidate>) {
        when(v){
            is JSONObject -> { val n=first(v,"n","nr","numero"); val name=first(v,"nm","nome","nomeCandidato"); val votes=number(v,"vap","v","votos","qtVotos"); val pct=numberDouble(v,"pvap","p","percentual","perc"); if((n!=null||name!=null)&&votes!=null&&(n?.length ?: 0)>0) out += ResultCandidate(first(v,"seq","sqcand","id") ?: n ?: "", n ?: "", name ?: "", votes.toLong(), pct ?: 0.0, 0, first(v,"e","eleito")?.lowercase() in setOf("s","sim","true","1")); for(k in v.keys()) walk(v.opt(k),out) }
            is JSONArray -> for(i in 0 until v.length()) walk(v.opt(i),out)
        }
    }
    private fun first(o:JSONObject,vararg ks:String):String?=ks.firstNotNullOfOrNull{ k->o.opt(k).takeIf{it!=null && it!=JSONObject.NULL && it.toString().isNotBlank()}?.toString() }
    private fun number(o:JSONObject,vararg ks:String):Double?=ks.firstNotNullOfOrNull{k->o.opt(k).toString().replace(".","").replace(",",".").toDoubleOrNull()}
    private fun numberDouble(o:JSONObject,vararg ks:String):Double?=ks.firstNotNullOfOrNull{k->o.opt(k).toString().replace(",",".").toDoubleOrNull()}
    private fun findLong(o:JSONObject,vararg ks:String):Long=number(o,*ks)?.toLong()?:0L
    private fun findString(o:JSONObject,vararg ks:String):String?=first(o,*ks)
}
