package br.com.votoaovivo

data class Candidate(
    val id: String,
    val name: String,
    val ballotName: String,
    val number: String,
    val party: String,
    val partyName: String,
    val office: String,
    val uf: String,
    val city: String,
    val situation: String,
    val occupation: String = "",
    val education: String = "",
    val photoUrl: String = "",
    val viceName: String = ""
)

data class ResultCandidate(
    val id: String,
    val number: String,
    val name: String,
    val votes: Long,
    val percent: Double,
    val position: Int,
    val elected: Boolean = false
)

data class ResultSnapshot(
    val office: String,
    val uf: String,
    val candidates: List<ResultCandidate>,
    val sectionsTotal: Int = 0,
    val sectionsCounted: Int = 0,
    val validVotes: Long = 0,
    val blankVotes: Long = 0,
    val nullVotes: Long = 0,
    val turnout: Long = 0,
    val abstention: Long = 0,
    val updatedAt: String = "",
    val final: Boolean = false
)
