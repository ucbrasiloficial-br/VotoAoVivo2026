package br.com.votoaovivo

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class SyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = try { TseClient.syncCandidates(applicationContext); Result.success() } catch (_: Throwable) { Result.retry() }
}
