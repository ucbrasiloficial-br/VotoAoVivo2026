package br.com.votoaovivo

import android.os.Bundle
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Navy = Color(0xFF071A31)
private val Blue = Color(0xFF0C5BEF)
private val Gold = Color(0xFFF5C451)
private val Bg = Color(0xFFF4F7FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("tse-candidates", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<SyncWorker>(6, TimeUnit.HOURS).build())
        setContent { VotoApp() }
    }
}

class AppState(private val ctx: android.content.Context) : androidx.lifecycle.ViewModel() {
    var candidates by mutableStateOf<List<Candidate>>(emptyList()); private set
    var favorites by mutableStateOf<Set<String>>(emptySet()); private set
    var results by mutableStateOf<ResultSnapshot?>(null); private set
    var selectedOffice by mutableStateOf("0001")
    var selectedUf by mutableStateOf("br")
    var loading by mutableStateOf(false); private set
    var message by mutableStateOf(""); private set
    init { favorites = ctx.getSharedPreferences("prefs",0).getStringSet("favorites",emptySet()) ?: emptySet(); refreshCandidates() }
    fun toggleFavorite(id:String){ favorites=(favorites.toMutableSet().apply{if(!add(id))remove(id)}).toSet();ctx.getSharedPreferences("prefs",0).edit().putStringSet("favorites",favorites).apply() }
    fun refreshCandidates(){ viewModelScope.launch { loading=true; candidates=TseClient.syncCandidates(ctx); loading=false } }
    fun refreshResult(){ viewModelScope.launch { loading=true; results=TseClient.result(selectedOffice,selectedUf); loading=false } }
}

@Composable fun VotoApp() {
    val ctx=androidx.compose.ui.platform.LocalContext.current
    val state:AppState=viewModel(factory=object:androidx.lifecycle.ViewModelProvider.Factory{override fun <T:androidx.lifecycle.ViewModel> create(c:Class<T>):T=AppState(ctx) as T})
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Candidate?>(null) }
    var search by remember { mutableStateOf("") }
    MaterialTheme(colorScheme=lightColorScheme(primary=Blue,background=Bg,surface=Color.White)) {
        Scaffold(bottomBar={NavigationBar{listOf(Icons.Default.Home,Icons.Default.Search,Icons.Default.Star,Icons.Default.BarChart).forEachIndexed{ i,icon->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(icon,null)},label={Text(listOf("Início","Pesquisar","Favoritos","Resultados")[i])})}}}) { pad ->
            Box(Modifier.padding(pad).fillMaxSize().background(Bg)) {
                when(tab){0->Home(state);1->SearchPage(state,search,{search=it},{selected=it});2->Favorites(state,{selected=it});3->ResultsPage(state)}
                selected?.let{Profile(it,state){selected=null}}
            }
        }
    }
}

@Composable fun Header(title:String="VOTO AO VIVO") { Row(Modifier.fillMaxWidth().background(Navy).padding(18.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.ExtraBold);Text("Eleições 2026",color=Color.White.copy(.65f),fontSize=12.sp)}}; val t=rememberInfiniteTransition(label="live");val a by t.animateFloat(1f,.25f,infiniteRepeatable(tween(750),RepeatMode.Reverse),label="pulse");Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(9.dp).alpha(a).clip(CircleShape).background(Color.Red));Spacer(Modifier.width(6.dp));Text("AO VIVO",color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp)}}

@Composable fun Home(s:AppState){ Header(); Column(Modifier.padding(16.dp)){Text("Acompanhe a apuração",fontSize=28.sp,fontWeight=FontWeight.Bold,color=Navy);Text("Dados eleitorais oficiais quando disponibilizados.",color=Color.Gray);Spacer(Modifier.height(18.dp)); LiveCard(s);Spacer(Modifier.height(18.dp)); listOf("0001" to "Presidente","0003" to "Governador","0005" to "Senador","0006" to "Deputado Federal","0007" to "Deputado Estadual").forEach{(c,n)->ElectionCard(n,c,s)}}}

@Composable fun LiveCard(s:AppState){Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Navy)){Column(Modifier.padding(20.dp)){Text("STATUS DA APURAÇÃO",color=Gold,fontWeight=FontWeight.Bold,fontSize=12.sp);Text(if(s.results?.final==true)"RESULTADO FINAL" else "Aguardando / apuração em andamento",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold);Text(if(s.results?.updatedAt?.isNotBlank()==true)"Última atualização: ${s.results!!.updatedAt}" else "A fonte oficial será consultada automaticamente.",color=Color.White.copy(.7f));Spacer(Modifier.height(12.dp));Button(onClick={s.refreshResult()},colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Navy)){Text("Atualizar agora",fontWeight=FontWeight.Bold)}}}}

@Composable fun ElectionCard(name:String,code:String,s:AppState){Card(Modifier.fillMaxWidth().padding(bottom=12.dp).clickable{ s.selectedOffice=code;s.refreshResult() },shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(name,Modifier.weight(1f),fontSize=18.sp,fontWeight=FontWeight.Bold,color=Navy);Icon(Icons.Default.ChevronRight,null)};if(s.results?.office==name&&s.results!!.candidates.isNotEmpty()){s.results!!.candidates.take(3).forEach{r->Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){Text("${r.position}º",Modifier.width(28.dp),fontWeight=FontWeight.Bold);Text(r.name,Modifier.weight(1f));Text("${r.percent.format()}%",fontWeight=FontWeight.Bold)}}}else Text("Toque para consultar a totalização oficial",color=Color.Gray,fontSize=13.sp)}}}

@Composable fun SearchPage(s:AppState,q:String,onQ:(String)->Unit,onSelect:(Candidate)->Unit){Header("Pesquisar candidatos");Column(Modifier.padding(14.dp)){OutlinedTextField(q,onQ,Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Nome, número ou partido")},leadingIcon={Icon(Icons.Default.Search,null)});Spacer(Modifier.height(10.dp));val list=s.candidates.filter{val x=q.trim();x.isBlank()||it.name.contains(x,true)||it.ballotName.contains(x,true)||it.number.contains(x)||it.party.contains(x,true)}.take(300);Text("${s.candidates.size} candidaturas carregadas",color=Color.Gray,fontSize=12.sp);LazyColumn{items(list,key={it.id}){CandidateRow(it,s,onSelect)}}}}

@Composable fun Favorites(s:AppState,onSelect:(Candidate)->Unit){Header("Meus favoritos");val list=s.candidates.filter{it.id in s.favorites};if(list.isEmpty())Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("Você ainda não favoritou candidatos.",color=Color.Gray)}else LazyColumn(Modifier.padding(14.dp)){items(list,key={it.id}){CandidateRow(it,s,onSelect)}}}

@Composable fun CandidateRow(c:Candidate,s:AppState,onSelect:(Candidate)->Unit){Card(Modifier.fillMaxWidth().padding(bottom=10.dp).clickable{onSelect(c)},shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){if(c.photoUrl.isNotBlank())AsyncImage(c.photoUrl,null,Modifier.size(62.dp).clip(CircleShape),contentScale=ContentScale.Crop)else Box(Modifier.size(62.dp).clip(CircleShape).background(Navy),contentAlignment=Alignment.Center){Text(c.ballotName.take(1).uppercase(),color=Color.White,fontWeight=FontWeight.Bold,fontSize=20.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.ballotName,fontWeight=FontWeight.Bold,color=Navy);Text("${c.party} • ${c.office}",fontSize=12.sp,color=Color.Gray);Text("Nº ${c.number} • ${c.uf}",fontSize=12.sp,color=Color.Gray)};IconButton(onClick={s.toggleFavorite(c.id)}){Icon(if(c.id in s.favorites)Icons.Default.Star else Icons.Default.StarBorder,null,tint=if(c.id in s.favorites)Gold else Color.Gray)}}}}

@Composable fun Profile(c:Candidate,s:AppState,close:()->Unit){DialogLike{Column(Modifier.fillMaxSize().background(Bg)){Row(Modifier.fillMaxWidth().background(Navy).padding(14.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=close){Icon(Icons.Default.ArrowBack,null,Color.White)};Text("Perfil do candidato",color=Color.White,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));IconButton(onClick={s.toggleFavorite(c.id)}){Icon(if(c.id in s.favorites)Icons.Default.Star else Icons.Default.StarBorder,null,Color.White)}};LazyColumn(Modifier.padding(16.dp)){item{if(c.photoUrl.isNotBlank())AsyncImage(c.photoUrl,null,Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(22.dp)),contentScale=ContentScale.Crop);Spacer(Modifier.height(16.dp));Text(c.ballotName,fontSize=30.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text(c.name,fontSize=15.sp,color=Color.Gray);Spacer(Modifier.height(12.dp));Info("Número",c.number);Info("Cargo",c.office);Info("Partido",if(c.partyName.isBlank())c.party else "${c.party} — ${c.partyName}");Info("UF",c.uf);Info("Situação",c.situation);if(c.viceName.isNotBlank())Info("Vice",c.viceName);Info("Ocupação",c.occupation);Info("Instrução",c.education);Spacer(Modifier.height(18.dp));Text("Fonte",fontWeight=FontWeight.Bold,color=Navy);Text("Dados cadastrais sincronizados a partir do conjunto público de Candidatos 2026 do TSE. Este aplicativo é independente.",fontSize=13.sp,color=Color.Gray)}}}}}
@Composable fun DialogLike(content: @Composable () -> Unit) = content
@Composable fun Info(a:String,b:String){if(b.isNotBlank())Column(Modifier.padding(vertical=7.dp)){Text(a.uppercase(),fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color.Gray);Text(b,fontSize=16.sp,color=Navy)}}

@Composable fun ResultsPage(s:AppState){Header("Resultados");Column(Modifier.padding(14.dp)){Text("Totalização oficial",fontSize=28.sp,fontWeight=FontWeight.Bold,color=Navy);Text("Brasil",color=Color.Gray);Spacer(Modifier.height(12.dp));s.results?.let{r->Text(r.office,fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Seções: ${r.sectionsCounted}/${r.sectionsTotal}");r.candidates.take(20).forEach{ResultRow(it)}}?:Text("Selecione um cargo na página inicial para consultar os resultados.",color=Color.Gray)}}
@Composable fun ResultRow(r:ResultCandidate){Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Text("${r.position}º",Modifier.width(34.dp),fontWeight=FontWeight.Bold,color=Blue);Column(Modifier.weight(1f)){Text(r.name,fontWeight=FontWeight.Bold);Text("${r.votes} votos",fontSize=12.sp,color=Color.Gray)};Text("${r.percent.format()}%",fontWeight=FontWeight.ExtraBold,color=Navy)}}}

private fun Double.format()=String.format(java.util.Locale("pt","BR"),"%.2f",this)
