# Voto ao Vivo 2026
Base Android mínima para validar a geração do APK. Sem TSE, AdMob ou dados eleitorais nesta etapa.
